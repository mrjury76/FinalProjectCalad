package com.example.project;

public class Item_Modal {
    int img;
    String name, amount;

    public Item_Modal(int img, String name, String amount) {
        this.img = img;
        this.name = name;
        this.amount = amount;
    }
}
